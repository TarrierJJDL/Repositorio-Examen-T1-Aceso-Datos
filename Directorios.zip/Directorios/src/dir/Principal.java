package dir;

import java.io.File;



public class Principal {
private File carpetaDeTrabajo = null;
		private Object[][] contenido;
		private int filas = 0;
		private int columnas = 3;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}
	public void GestionFicherosImpl() {
		carpetaDeTrabajo = File.listRoots()[0];
		actualiza();
	}

	private void actualiza() {

		String[] ficheros = carpetaDeTrabajo.list(); // obtener los nombres
		// calcular el n�mero de filas necesario
		filas = ficheros.length / columnas;
		if (filas * columnas < ficheros.length) {
			filas++; // si hay resto necesitamos una fila m�s
		}

		// dimensionar la matriz contenido seg�n los resultados

		contenido = new String[filas][columnas];
		// Rellenar contenido con los nombres obtenidos
		for (int i = 0; i < columnas; i++) {
			for (int j = 0; j < filas; j++) {
				int ind = j * columnas + i;
				if (ind < ficheros.length) {
					contenido[j][i] = ficheros[ind];
				} else {
					contenido[j][i] = "";
				}
			}
		}
	}
	
	public static void localizar(){
		
	}
	
	public void comparar(String arg0, String arg1) throws Exception{
		
			File file = new File(carpetaDeTrabajo,arg0);
			File file1 = new File(carpetaDeTrabajo,arg1);
			if (!file.exists()) {
				throw new Exception("El fichero "
						+ file.getAbsolutePath() + ". No existe");
			}
			
			if (file1.exists()) {
				throw new Exception("El fichero "
						+ file.getAbsolutePath() + ". Existe");
			}
			
			
		
	}

}
