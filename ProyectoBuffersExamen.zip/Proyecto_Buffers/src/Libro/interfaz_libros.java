package Libro;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.Color;

public class interfaz_libros extends JFrame {

	private JButton btnBuscar;
	private JLabel lblAoDePublicacion;
	private JPanel contentPane;
	private JTextArea lista;
	private JTextField publi;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					interfaz_libros frame = new interfaz_libros();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	/**
	 * Create the frame.
	 */
	public interfaz_libros() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblAoDePublicacion = new JLabel("A\u00F1o de publicacion");
		lblAoDePublicacion.setBounds(85, 66, 89, 14);
		contentPane.add(lblAoDePublicacion);
		
		publi = new JTextField();
		publi.setBounds(179, 63, 86, 20);
		contentPane.add(publi);
		publi.setColumns(10);
		
		btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				lista.setText(localizar());
			}
		});
		btnBuscar.setBounds(283, 62, 89, 23);
		contentPane.add(btnBuscar);
		
		lista = new JTextArea();
		lista.setBounds(97, 124, 241, 127);
		contentPane.add(lista);
	}
	
	public void localizar() throws Exception {
		int cont=0;
		ArrayList<Libro> recuperar_todos=new ArrayList<Libro>();
				
		
		recuperar_todos.add(new Libro (1,"Hola","Jorge","2008","Juan Baldes",205));
			
		Iterator it=recuperar_todos.iterator();
		while(it.hasNext()) {
			Libro l11 = (Libro) it.next();
			if (l11.getPubli()==publi.getText()) {
				cont++;
			}
		}
		if (cont==0) {
			throw new Exception("Ninguna coincidencia");
			}
		else {
			System.out.println(cont+" han coincidido con el resultado de busqueda");
		}
	}
}
